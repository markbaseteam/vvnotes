
# Figma

<iframe src="https://www.notion.so/passcart/MVP-Home-62e483b654ad4834853d703b18554085" allow="fullscreen" allowfullscreen="" style="height: 100%; width: 100%; aspect-ratio: 4 / 3;"></iframe>


/ifram

<iframe style="border: 1px solid rgba(0, 0, 0, 0.1);" width="800" height="450" src="https://www.figma.com/embed?embed_host=share&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FncjwNnzZt2dIqHftFPL9Ib%2FFigJam-Basics%3Fnode-id%3D0%253A1" allowfullscreen></iframe>

https://www.youtube.com/watch?v=wkY_1Y7edhU


- everything 
- that you do is great 
- figma ui design is great
- figma got acquired by Adobe for $20bn. do you know that?

figma is looking after that itch that it looks great where ever you want 

[[My Core Principles]]

[[2022-09-17]] i have to earn the living dead


https://web.getmatter.app/entry/13164071

https://liveblocks.io/

![[Screen Shot 2022-08-31 at 10.06.52 AM.png]]


![[State of Customer Onboarding 2022.pdf]]


<iframe src="https://github.com/maximevaillancourt/digital-garden-jekyll-template" allow="fullscreen" allowfullscreen="" style="height: 100%; width: 100%; aspect-ratio: 16 / 9;"></iframe>


https://twitter.com/amasad/status/1571540482412646401?s=20&t=Oxxrg4D0aK4u9JOwd-_m-w

<iframe style="border: 0; width: 100%; height: 450px;" allowfullscreen frameborder="0" src="https://raindrop.io/vvonbookmarks/matter-articles-25784284/embed/theme=dark"></iframe>

https://www.instagram.com/reel/CikC0uLIXWX/?utm_source=ig_web_button_share_sheet




